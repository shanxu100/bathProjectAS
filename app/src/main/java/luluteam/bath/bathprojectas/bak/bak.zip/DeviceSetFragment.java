package luluteam.bath.bathprojectas.bak;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;

import java.util.HashMap;

import luluteam.bath.bathprojectas.R;
import luluteam.bath.bathprojectas.constants.WebConstant;
import luluteam.bath.bathprojectas.utils.CalendarUtil;
import luluteam.bath.bathprojectas.utils.OkHttpManager;
import luluteam.bath.bathprojectas.utils.SharedPreferencesUtil;
import luluteam.bath.bathprojectas.utils.ToastUtil;
import luluteam.bath.bathprojectas.view.dialog.datePickDialog.DatePick;
import luluteam.bath.bathprojectas.view.dialog.datePickDialog.DatePickDialog;
import luluteam.bath.bathprojectas.view.spinner.JJYSpinner;

/**
 * Created by 123 on 2017/11/16.
 */
@Deprecated
public class DeviceSetFragment extends Fragment implements View.OnClickListener {

    /**
     * 一键系列
     */
    //一键设置全部
    private CheckBox cb_SetAll;
    //一键恢复默认设置
    private Button btn_SetAll;

    /**
     * 采集卡系列
     */
    //采用系统时间
    private CheckBox cb_useSysTime;
    //采集卡用户输入时间
    private EditText et_cardTime;
    //采集卡确定提交时间
    private Button btn_cardTime;

    /**
     * 光照探头系列
     */
    //探头厕所类型选择
    private JJYSpinner spinner_tantouToilet;
    //探头阈值设定
    private EditText et_tantouValue;
    //探头确定设置
    private Button btn_tantou;

    /**
     * 定时器系列
     */
    //定时器厕所类型选择
    private JJYSpinner spinner_timerToilet;
    //辅灯开始时间
    private EditText et_fudeng_StartTime;
    //辅灯结束时间
    private EditText et_fudeng_endTime;
    //主灯延时时间
    private EditText et_zhudeng_delayTime;
    //音响开始时间
    private EditText et_yinxiang_StartTime;
    //音响结束时间
    private EditText et_yinxiang_endTime;
    //音响延时时间
    private EditText et_yinxiang_delayTime;
    //消毒开始时间
    private EditText et_xiaodu_StartTime;
    //消毒结束时间
    private EditText et_xiaodu_endTime;
    //消毒延时时间
    private EditText et_xiaodu_delayTime;
    //灯确定
    private Button btn_light;
    //音响确定
    private Button btn_yinxiang;
    //消毒确定
    private Button btn_xiaodu;

    private Context mContext;

    //卫浴的编号
    private String toiletId = "12345678";

    //用来接收socket的数据参数
    HashMap<String, HashMap<String, String>> paramsSocket;
    String[] arrToiletName = {"男厕", "女厕", "殘卫"};

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_device_set, container, false);
        mContext = getContext();
        initView(view);
        setChooseTime();
        return view;
    }

    private void initView(View view) {
        cb_SetAll = (CheckBox) view.findViewById(R.id.setAll_cb);
        btn_SetAll = (Button) view.findViewById(R.id.defaultAll_btn);

        cb_useSysTime = (CheckBox) view.findViewById(R.id.systemTime_cb);
        et_cardTime = (EditText) view.findViewById(R.id.cardTime_et);
        btn_cardTime = (Button) view.findViewById(R.id.cardTime_btn);

        spinner_tantouToilet = (JJYSpinner) view.findViewById(R.id.lightDetector_spinner);
        et_tantouValue = (EditText) view.findViewById(R.id.lightDetector_et);
        btn_tantou = (Button) view.findViewById(R.id.lightDetector_btn);

        spinner_timerToilet = (JJYSpinner) view.findViewById(R.id.timer_spinner);
        et_fudeng_StartTime = (EditText) view.findViewById(R.id.fudeng_startTime_et);
        et_fudeng_endTime = (EditText) view.findViewById(R.id.fudeng_endTime_et);
        et_zhudeng_delayTime = (EditText) view.findViewById(R.id.zhudeng_delayTime_et);
        btn_light = (Button) view.findViewById(R.id.lightTimer_btn);

        et_xiaodu_StartTime = (EditText) view.findViewById(R.id.xiaodu_startTime_et);
        et_xiaodu_endTime = (EditText) view.findViewById(R.id.xiaodu_endTime_et);
        et_xiaodu_delayTime = (EditText) view.findViewById(R.id.xiaodu_delayTime_et);
        btn_xiaodu = (Button) view.findViewById(R.id.xiaodu_btn);

        et_yinxiang_StartTime = (EditText) view.findViewById(R.id.audioTimer_startTime_et);
        et_yinxiang_endTime = (EditText) view.findViewById(R.id.audioTimer_endTime_et);
        et_yinxiang_delayTime = (EditText) view.findViewById(R.id.audioTimer_delayTime_et);
        btn_yinxiang = (Button) view.findViewById(R.id.audioTimer_btn);
//        spinner_timerToilet.setSelectedposition(0);
//        spinner_tantouToilet.setSelectedposition(0);
        /**
         * 禁止editText弹出软键盘
         */
        et_fudeng_StartTime.setInputType(InputType.TYPE_NULL);
        et_fudeng_endTime.setInputType(InputType.TYPE_NULL);
        et_xiaodu_StartTime.setInputType(InputType.TYPE_NULL);
        et_xiaodu_endTime.setInputType(InputType.TYPE_NULL);
        et_yinxiang_StartTime.setInputType(InputType.TYPE_NULL);
        et_yinxiang_endTime.setInputType(InputType.TYPE_NULL);
        et_cardTime.setInputType(InputType.TYPE_NULL);

        setSomeListener();
        setSpinnerValues(spinner_tantouToilet);
        setSpinnerValues(spinner_timerToilet);

        /**
         * 探头
         */
        spinner_tantouToilet.setOnSpinnerItemSelectedListener(new JJYSpinner.OnSpinnerItemSelectedListener() {
            @Override
            public void onSelected(int postion) {
                if (paramsSocket != null) {
                    setThresholdLight(paramsSocket.get(arrToiletName[postion]));
                }

            }
        });

        /**
         * 定时器
         */
        spinner_timerToilet.setOnSpinnerItemSelectedListener(new JJYSpinner.OnSpinnerItemSelectedListener() {
            @Override
            public void onSelected(int postion) {
                if (paramsSocket != null) {
                    setTimerBySocket(paramsSocket.get(arrToiletName[postion]), "L");
                    setTimerBySocket(paramsSocket.get(arrToiletName[postion]), "M");
                    setTimerBySocket(paramsSocket.get(arrToiletName[postion]), "N");
                }
            }
        });
    }

    private void setSomeListener() {
        cb_SetAll.setOnCheckedChangeListener(new myCheckBoxOnChangedListener());
        cb_useSysTime.setOnCheckedChangeListener(new myCheckBoxOnChangedListener());
        btn_SetAll.setOnClickListener(this);
        btn_cardTime.setOnClickListener(this);
        btn_tantou.setOnClickListener(this);
        btn_yinxiang.setOnClickListener(this);
        btn_xiaodu.setOnClickListener(this);
        btn_light.setOnClickListener(this);

    }


    private class myCheckBoxOnChangedListener implements CompoundButton.OnCheckedChangeListener {

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (buttonView.equals(cb_SetAll)) {
                if (isChecked) {
//                    setSystemTime(true);
                }
            } else if (buttonView.equals(cb_useSysTime)) {
                if (isChecked) {
                    //禁用用户设置采集卡时间
                    et_cardTime.setEnabled(false);
                    btn_cardTime.setEnabled(false);
                    setSystemTime(true);
                } else {
                    //启用用户设置采集卡时间
                    et_cardTime.setEnabled(true);
                    btn_cardTime.setEnabled(true);
                }
            }
        }
    }

    /**
     * 设置采集卡校准系统时间
     *
     * @param flag true采用系统时间，false则采用用户输入的时间
     */
    private void setSystemTime(boolean flag) {
        HashMap<String, String> map = new HashMap<>();
        String time = "";
        map.put("toiletId", getToiletId());
        if (flag) {
            time = CalendarUtil.getDateTimeString("-", "T");
        } else {
            time = et_cardTime.getText().toString();
        }
//        System.out.println("curent time:"+time);
        map.put("time", time);
        map.put("isBroadcast", "false");
        if (!flag && time.equals(""))
            ToastUtil.showShortToast(mContext, "请设置采集卡时间！！！");
        else {
            OkHttpManager.CommonPostAsyn(WebConstant.SET_SYSTEM_CLOCK, map, new OkHttpManager.ResultCallback() {
                @Override
                public void onCallBack(OkHttpManager.State state, String result) {
                    System.out.println(result);
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (state == OkHttpManager.State.SUCCESS) {
                                ToastUtil.showShortToast(mContext, "设置成功！");

                            } else {
                                ToastUtil.showShortToast(mContext, "设置失败：" + result);
                            }
                        }
                    });
                }
            });
        }
    }

    private String getToiletId() {
        if (!"".equals(SharedPreferencesUtil.getString(getActivity(), "toiletId"))) {
            toiletId = SharedPreferencesUtil.getString(getActivity(), "toiletId");
        }
        return toiletId;
    }

    /**
     * 设置探头参数
     */
    private void setTantou() {
        String value = et_tantouValue.getText().toString();
        String usage = getSpinnerValue(spinner_tantouToilet);
        if ("".equals(value)) {
            ToastUtil.showShortToast(mContext, "请输入数值！！");
        } else {
            HashMap<String, String> map = new HashMap<>();
            map.put("toiletId", getToiletId());
            map.put("usage", usage);
            map.put("deviceType", "J");
            map.put("value", value);
            map.put("isBroadcast", "false");
            OkHttpManager.CommonPostAsyn(WebConstant.SET_THRESHOLD, map, new OkHttpManager.ResultCallback() {
                @Override
                public void onCallBack(OkHttpManager.State state, String result) {
                    System.out.println(result);
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (state == OkHttpManager.State.SUCCESS) {
                                ToastUtil.showShortToast(mContext, "设置成功！");

                            }else {
                                ToastUtil.showShortToast(mContext, "设置失败：" + result);
                            }
                        }
                    });
                }
            });
//            map.put("")
        }
    }

    /**
     * 根据输入的设备类型，设置相应的开始，结束，延时，时间
     *
     * @param deviceType L,M,N
     */
    private void setTimer(String deviceType) {
        String startTime = "";
        String endTime = "";
        String delayTime = "";
        switch (deviceType) {
            case "L":
                startTime = et_fudeng_StartTime.getText().toString();
                endTime = et_fudeng_endTime.getText().toString();
                delayTime = et_zhudeng_delayTime.getText().toString();
                break;
            case "M":
                startTime = et_yinxiang_StartTime.getText().toString();
                endTime = et_yinxiang_endTime.getText().toString();
                delayTime = et_yinxiang_delayTime.getText().toString();
                break;
            case "N":
                startTime = et_xiaodu_StartTime.getText().toString();
                endTime = et_xiaodu_endTime.getText().toString();
                delayTime = et_xiaodu_delayTime.getText().toString();
                break;
        }
        String usage = getSpinnerValue(spinner_timerToilet);
        if ("".equals(startTime) || "".equals(endTime) || "".equals(delayTime)) {
            ToastUtil.showShortToast(mContext, "请输入数值！");
        } else {
            HashMap<String, String> map = new HashMap<>();
            map.put("toiletId", getToiletId());
            map.put("usage", usage);
            map.put("deviceType", deviceType);
            map.put("time", delayTime);
            map.put("startTime", startTime);
            map.put("stopTime", endTime);
            map.put("isBroadcast", "false");
            OkHttpManager.CommonPostAsyn(WebConstant.SET_TIMER, map, new OkHttpManager.ResultCallback() {
                @Override
                public void onCallBack(OkHttpManager.State state, String result) {
                    System.out.println(result);
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (state == OkHttpManager.State.SUCCESS) {
                                ToastUtil.showShortToast(mContext, "设置成功！");

                            } else {
                                ToastUtil.showShortToast(mContext, "设置失败：" + result);
                            }
                        }
                    });
                }
            });
        }
    }

    /**
     * 恢复默认设置
     */
    private void setDefaultAll() {
        HashMap<String, String> map = new HashMap<>();
        map.put("toiletId", getToiletId());
        map.put("isBroadcast", "false");
        OkHttpManager.CommonPostAsyn(WebConstant.SET_DEFAULT_ALL, map, new OkHttpManager.ResultCallback() {
            @Override
            public void onCallBack(OkHttpManager.State state, String result) {
                System.out.println(result);
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (state == OkHttpManager.State.SUCCESS) {
                            ToastUtil.showShortToast(mContext, "设置成功！");

                        } else {
                            ToastUtil.showShortToast(mContext, "设置失败：" + result);
                        }
                    }
                });
            }
        });
    }

    private String getSpinnerValue(JJYSpinner spinner) {
        return (spinner.getSelectedposition() + 1) + "";
    }

    private void setSpinnerValues(JJYSpinner spinner) {

        spinner.additem(arrToiletName);
    }

    /**
     * 对一些需要选择时间的EditText,使用该方法
     */
    private void setChooseTime() {
        setEditTextFocus(et_cardTime, DatePick.TYPE_ALL);
        setEditTextFocus(et_fudeng_StartTime, DatePick.TYPE_ONLYTIME);
        setEditTextFocus(et_fudeng_endTime, DatePick.TYPE_ONLYTIME);
        setEditTextFocus(et_xiaodu_StartTime, DatePick.TYPE_ONLYTIME);
        setEditTextFocus(et_xiaodu_endTime, DatePick.TYPE_ONLYTIME);
        setEditTextFocus(et_yinxiang_StartTime, DatePick.TYPE_ONLYTIME);
        setEditTextFocus(et_yinxiang_endTime, DatePick.TYPE_ONLYTIME);
    }

    private void setEditTextFocus(EditText editText, int type) {
        editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editText.isFocused()) {
                    showDatePickDialog(editText, type);
                }
            }
        });
        editText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (editText.isFocused()) {
                    showDatePickDialog(editText, type);
                }
            }
        });
    }

    private void showDatePickDialog(EditText editText, int type) {
        DatePickDialog.Builder builder = new DatePickDialog.Builder(mContext);
        DatePickDialog dialog = builder.build();
        builder.setTitle("日期时间选择框")
                .setDatePickType(type)
                .setPositiveButton("确定", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DatePick pick = dialog.getPick();
                        editText.setText(pick.getResultDate());
//                        ToastUtil.showShortToast(mContext,pick.getResultDate());
                        dialog.dismiss();
                    }
                })
                .setCancelButton("取消", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                    }
                });
        dialog.show();
    }

    /**
     * 更新参数阈值
     *
     * @param time
     * @param params
     */
    public void setParamsBySocket(String time, HashMap<String, HashMap<String, String>> params) {
        /**
         * 设置系统时间？
         */
        et_cardTime.setText(time);
        /**
         * 设置光照探头阈值，以及定时器相关参数的设定
         */
        paramsSocket = params;
        setThresholdLight(params.get(arrToiletName[spinner_tantouToilet.getSelectedposition()]));
        setTimerBySocket(params.get(arrToiletName[spinner_timerToilet.getSelectedposition()]), "L");
        setTimerBySocket(params.get(arrToiletName[spinner_timerToilet.getSelectedposition()]), "M");
        setTimerBySocket(params.get(arrToiletName[spinner_timerToilet.getSelectedposition()]), "N");
    }

    /**
     * params 为男厕，女厕，殘卫的数据
     *
     * @param params
     */
    private void setThresholdLight(HashMap<String, String> params) {
        et_tantouValue.setText(params.get("thresholdLight"));
    }

    /**
     * @param params     男厕，女厕，殘卫的数据
     * @param deviceType L,M,N 分别表示灯光，音响，消毒灯
     */
    private void setTimerBySocket(HashMap<String, String> params, String deviceType) {
        switch (deviceType) {
            case "L":
                et_fudeng_StartTime.setText(params.get("light_startTime"));
                et_fudeng_endTime.setText(params.get("light_stopTime"));
                et_zhudeng_delayTime.setText(params.get("light_duration"));
                break;
            case "M":
                et_yinxiang_StartTime.setText(params.get("audio_startTime"));
                et_yinxiang_endTime.setText(params.get("audio_stopTime"));
                et_yinxiang_delayTime.setText(params.get("audio_duration"));
                break;
            case "N":
                et_xiaodu_StartTime.setText(params.get("Sterilamp_startTime"));
                et_xiaodu_endTime.setText(params.get("Sterilamp_stopTime"));
                et_xiaodu_delayTime.setText(params.get("Sterilamp_duration"));
                break;
        }
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.cardTime_btn:
                setSystemTime(false);
                break;
            case R.id.lightDetector_btn:
                setTantou();
                break;
            case R.id.lightTimer_btn:
                setTimer("L");
                break;
            case R.id.audioTimer_btn:
                setTimer("M");
                break;
            case R.id.xiaodu_btn:
                setTimer("N");
                break;
            case R.id.defaultAll_btn:
                setDefaultAll();
                break;
        }
    }
}
