package luluteam.bath.bathprojectas.bak;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import luluteam.bath.bathprojectas.R;
import luluteam.bath.bathprojectas.model.RemoteControl.RemoteCtrlDevices;

/**
 *
 * Created by TC on 2017/11/17.
 */
public class RemoteCtrlFragment extends Fragment implements RemoteControlAty.RecordInfoCallback {

    private ListView remoteCtrlManLv;
    private RemoteControlAdapter adapter;
    protected String usage = "男厕";//厕所类型
    protected boolean allDeviceIsCtrl;

    public void setUsage(String usage) {
        this.usage = usage;
    }

    public String getUsage() {
        return this.usage;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_remote_ctrl, container, false);
        remoteCtrlManLv = (ListView) view.findViewById(R.id.remoteCtrlManLv);
        remoteCtrlManLv.setAdapter(adapter);
        return view;
    }
    @Override
    public void onStateChange(RemoteCtrlDevices devices, boolean allDeviceIsCtrl) {
        adapter.notifyDataChange(devices, allDeviceIsCtrl);
    }

    public void setAdapter(RemoteControlAdapter adapter) {
        this.adapter = adapter;
    }
}






