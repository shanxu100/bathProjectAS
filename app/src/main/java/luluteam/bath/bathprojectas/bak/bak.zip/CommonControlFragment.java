package luluteam.bath.bathprojectas.fragment.control;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

import luluteam.bath.bathprojectas.R;
import luluteam.bath.bathprojectas.constants.APPConstant;
import luluteam.bath.bathprojectas.constants.WebConstant;
import luluteam.bath.bathprojectas.fragment.BaseFragment;
import luluteam.bath.bathprojectas.utils.OkHttpManager;
import luluteam.bath.bathprojectas.utils.ToastUtil;
import luluteam.bath.bathprojectas.view.dialog.LoadingDialog;

import static luluteam.bath.bathprojectas.fragment.main.ControlFragment.DIALOG_TIME_DELAY;


/**
 * 显示水电表和公用设备
 */
@Deprecated
public class CommonControlFragment extends BaseFragment {

    private final String usage = "公用";
    private TextView waterMeterTv;//水表数据显示控件
    private String waterMeterTvValue = "-";//水表数据
    private TextView elecMeterTv;//电表数据显示控件
    private String elecMeterTvValue = "-";//电表数据

    private ToggleButton voiceCtrl1_tb, voiceCtrl2_tb;//语音提示状态控制按钮、状态保持按钮


    private boolean voiceCtrlTbValue1 = false;
    private boolean voiceCtrlTbValue2 = false;


    public CommonControlFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = initUIForCommonUse(inflater, container);
        initDataForCommonUse();
        return view;
    }

    /**
     * 显示 公用设备 的时候，加载的数据
     */
    private void initDataForCommonUse() {
        setWaterMeterTvValue(waterMeterTvValue);
        setElecMeterTvValue(elecMeterTvValue);
        setVoiceCtrlTb1(voiceCtrlTbValue1);
        setVoiceCtrlTb2(voiceCtrlTbValue2);
    }

    /**
     * 显示 公用设备 的时候加载的UI
     *
     * @param inflater
     * @param container
     */
    private View initUIForCommonUse(LayoutInflater inflater, ViewGroup container) {
        View view = inflater.inflate(R.layout.fragment_common_control, container, false);
        LoadingDialog loadingDialog = new LoadingDialog(getContext());
        loadingDialog.setCanceledOnTouchOutside(false);
        loadingDialog.setLoadingText("正在更新数据");
        elecMeterTv = (TextView) view.findViewById(R.id.elecMeterTv);
        waterMeterTv = (TextView) view.findViewById(R.id.waterMeterTv);

        voiceCtrl1_tb = (ToggleButton) view.findViewById(R.id.voiceCtrl1_tb);
        voiceCtrl2_tb = (ToggleButton) view.findViewById(R.id.voiceCtrl2_tb);

        voiceCtrl1_tb.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    if (isControlled()) {
                        loadingDialog.show();
                        HashMap<String, String> params = new HashMap<>();
                        params.put("toiletId", APPConstant.TOILETID);
                        //TODO 语音提示 暂用 “男厕”
                        params.put("usage", APPConstant.UsageMap.get("男厕"));
                        params.put("deviceType", APPConstant.deviceTypeMap.get("语音提示"));
                        params.put("cmd", voiceCtrl1_tb.isChecked() ? "false" : "true");
                        OkHttpManager.CommonPostAsyn(WebConstant.SEND_CMD, params, new OkHttpManager.ResultCallback() {
                            @Override
                            public void onCallBack(OkHttpManager.State state, String result) {
                                if (state != OkHttpManager.State.SUCCESS) {
                                    getActivity().runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            ToastUtil.showShortToast(getContext(), "操作失败：" + result);
                                        }
                                    });
                                }

                            }
                        });
                        new Timer().schedule(new TimerTask() {
                            @Override
                            public void run() {
                                loadingDialog.dismiss();
                            }
                        }, DIALOG_TIME_DELAY);
                    } else {
                        ToastUtil.showShortToast(view.getContext(), "请打开远程控制总开关!");
                    }
                }
                return true;
            }
        });
        voiceCtrl2_tb.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    if (isControlled()) {
                        loadingDialog.show();
                        HashMap<String, String> params = new HashMap<>();
                        params.put("toiletId", APPConstant.TOILETID);
                        //TODO 语音提示 暂用 “男厕”
                        params.put("usage", APPConstant.UsageMap.get("男厕"));
                        params.put("deviceType", APPConstant.deviceTypeMap.get("语音提示"));
                        params.put("action", voiceCtrl2_tb.isChecked() ? "false" : "true");
                        OkHttpManager.CommonPostAsyn(WebConstant.INTO_OR_EXIT_REMOTE_CTRL, params, new OkHttpManager.ResultCallback() {
                            @Override
                            public void onCallBack(OkHttpManager.State state, String result) {
                                if (state != OkHttpManager.State.SUCCESS) {
                                    getActivity().runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            ToastUtil.showShortToast(getContext(), "操作失败：" + result);
                                        }
                                    });
                                }
                            }
                        });
                        new Timer().schedule(new TimerTask() {
                            @Override
                            public void run() {
                                loadingDialog.dismiss();
                            }
                        }, DIALOG_TIME_DELAY);
                    } else {
                        ToastUtil.showShortToast(view.getContext(), "请打开远程控制总开关!");
                    }
                }
                return true;
            }
        });
        return view;
    }

    public void setVoiceCtrlTb1(boolean isCheck) {
        voiceCtrlTbValue1 = isCheck;
        if (null != this.voiceCtrl1_tb) {
            this.voiceCtrl1_tb.setChecked(isCheck);
        }
    }

    public void setVoiceCtrlTb2(boolean isCheck) {
        voiceCtrlTbValue2 = isCheck;
        if (null != this.voiceCtrl2_tb) {
            this.voiceCtrl2_tb.setChecked(isCheck);
        }
    }


    /**
     * 设置电表值
     *
     * @param num
     */
    public void setElecMeterTvValue(String num) {
        try {
            this.elecMeterTvValue = num;
            int elecValue = Integer.parseInt(num);
            if (elecValue < 0 || elecValue > 9999999) {
                return;
            }
//            StringBuilder value = new StringBuilder(elecMeterTvValue);
//            value.insert(elecMeterTvValue.length() - 2, ".");
            String value = String.format( "%.2f",elecValue * 0.01);
            if (null != this.elecMeterTv) {
                this.elecMeterTv.setText(value);
            }
        } catch (Exception e) {
            System.err.println("设置电表值：" + num);
//            e.printStackTrace();
        }
    }

    /**
     * 设置水表值
     *
     * @param num
     */
    public void setWaterMeterTvValue(String num) {
        try {
            this.waterMeterTvValue = num;
            int waterValue = Integer.parseInt(num);
            if (waterValue < 0 || waterValue > 999999) {
                return;
            }
//            StringBuilder value = new StringBuilder(waterMeterTvValue);
//            value.insert(waterMeterTvValue.length() - 1, ".");
            String value = String.format( "%.1f",waterValue * 0.1);

            if (null != this.waterMeterTv) {
                this.waterMeterTv.setText(value.toString());
            }
        } catch (Exception e) {
            System.err.println("设置水表值：" + num);
//            e.printStackTrace();
        }
    }

    /**
     * 判断当前是否处于 远程控制状态
     *
     * @return
     */
    public boolean isControlled() {
        if (getActivity() instanceof ControlActivity) {
            return ((ControlActivity) getActivity()).isControlled();
        }
        return false;
    }

}
