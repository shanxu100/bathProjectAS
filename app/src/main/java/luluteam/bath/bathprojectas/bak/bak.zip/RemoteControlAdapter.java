package luluteam.bath.bathprojectas.bak;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

import luluteam.bath.bathprojectas.R;
import luluteam.bath.bathprojectas.constants.APPConstant;
import luluteam.bath.bathprojectas.constants.WebConstant;
import luluteam.bath.bathprojectas.model.RemoteControl.RemoteCtrlDevices;
import luluteam.bath.bathprojectas.utils.OkHttpManager;
import luluteam.bath.bathprojectas.utils.ToastUtil;
import luluteam.bath.bathprojectas.view.dialog.LoadingDialog;

import static luluteam.bath.bathprojectas.utils.deviceTransformUtil.bathNameToUsage;
import static luluteam.bath.bathprojectas.utils.deviceTransformUtil.deviceNameToDeviceType;


/**
 * TC 2017-10-23
 */
@SuppressWarnings("all")
public class RemoteControlAdapter extends BaseAdapter {

    private RemoteCtrlDevices bathDevices;
    private boolean allDevicesIsCtrl;//远程控制或者禁止远程控制的总开关

    private LoadingDialog loadingDialog;//用于加载数据时候的一个缓冲

    private Context context;

    public void setCtrlOrNotCtrl(boolean x) {
        this.allDevicesIsCtrl = x;
    }

    public RemoteControlAdapter(Context context, RemoteCtrlDevices bathDevices, boolean b) {
        this.context = context;
        this.bathDevices = bathDevices;
        this.allDevicesIsCtrl = b;
        loadingDialog = new LoadingDialog(context);
        loadingDialog.setCanceledOnTouchOutside(false);
        loadingDialog.setLoadingText("正在更新数据");
    }

    /**
     * 通知数据实时改变
     *
     * @param ctrlOrNotCtrl 是否远程控制
     */
    public void notifyDataChange(RemoteCtrlDevices devices, boolean ctrlOrNotCtrl) {
        this.bathDevices = devices;
        this.allDevicesIsCtrl = ctrlOrNotCtrl;
        this.notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return bathDevices.getDeviceNames().size();
    }

    @Override
    public Object getItem(int position) {
        return bathDevices.getDeviceNames().get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    /*
    @SuppressLint("ClickableViewAccessibility")
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder_RemoteControlItem holder = null;
        if (convertView == null) {
            holder = new ViewHolder_RemoteControlItem();
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_remote_control_item, null);
            holder.name = (TextView) convertView.findViewById(R.id.item_name);
            holder.item_icon = (ImageView) convertView.findViewById(R.id.item_icon);
            holder.item_tb = (ToggleButton) convertView.findViewById(R.id.item_tb);
            holder.item_tv = (TextView) convertView.findViewById(R.id.item_tv);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder_RemoteControlItem) convertView.getTag();
        }
        holder.name.setText(getName(position));
        final ViewHolder_RemoteControlItem finalHolder = holder;
        switch (getName(position)) {
            case "光照探头\n(LUX)":
            case "人体感应\n探头(次)":
                holder.item_tb.setVisibility(View.INVISIBLE);
                holder.item_icon.setVisibility(View.INVISIBLE);
                holder.item_tv.setText(getStatus(position).toString());
                holder.item_tv.setVisibility(View.VISIBLE);
                break;
            default:
                holder.item_tv.setVisibility(View.INVISIBLE);
                setIconOff_ON(getName(position), holder.item_icon, getStatus(position) == 1 ? true : false);//设置ImageView的状态，设备状态
                holder.item_icon.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View view, MotionEvent motionEvent) {
                        if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                            if (allDevicesIsCtrl) {
                                if (getIsCtrl(position)) {
                                    loadingDialog.show();
                                    HashMap<String, String> params = new HashMap<>();
                                    params.put("toiletId", APPConstant.TOILETID);
                                    params.put("usage", bathDevices.getUsage());
                                    params.put("deviceType", deviceNameToDeviceType(getName(position)));
                                    params.put("cmd", finalHolder.item_tb.isChecked() ? "false" : "true");
                                    OkHttpManager.CommonPostAsyn(WebConstant.SEND_CMD, params, new OkHttpManager.ResultCallback() {
                                        @Override
                                        public void onCallBack(String result) {
                                        }
                                    });
                                    new Timer().schedule(new TimerTask() {
                                        @Override
                                        public void run() {
                                            loadingDialog.dismiss();
                                        }
                                    }, RemoteControlAty.DIALOG_TIME_DELAY);
                                } else
                                    ToastUtil.showShortToast(view.getContext(), "请打开该设备的远程控制开关!");
                            } else ToastUtil.showShortToast(view.getContext(), "请打开远程控制总开关!");
                        }
                        return true;
                    }
                });
                holder.item_tb.setChecked(getIsCtrl(position));//设置ToggleButton的状态，远程控制子开关
                holder.item_tb.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View view, MotionEvent motionEvent) {
                        if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                            if (allDevicesIsCtrl) {
                                loadingDialog.show();
                                HashMap<String, String> params = new HashMap<>();
                                params.put("toiletId", APPConstant.TOILETID);
                                params.put("usage", bathDevices.getUsage());
                                params.put("deviceType", deviceNameToDeviceType(getName(position)));
                                params.put("action", getIsCtrl(position) ? "false" : "true");
                                OkHttpManager.CommonPostAsyn(WebConstant.SEND_CMD, params, new OkHttpManager.ResultCallback() {
                                    @Override
                                    public void onCallBack(String result) {
                                    }
                                });
                                new Timer().schedule(new TimerTask() {
                                    @Override
                                    public void run() {
                                        loadingDialog.dismiss();
                                    }
                                }, RemoteControlAty.DIALOG_TIME_DELAY);
                            } else ToastUtil.showShortToast(view.getContext(), "请打开远程控制总开关!");
                        }
                        return true;
                    }
                });
                holder.item_icon.setVisibility(View.VISIBLE);
                holder.item_tb.setVisibility(View.VISIBLE);
        }
        return convertView;
    }
    */


    @SuppressLint("ClickableViewAccessibility")
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.cell_remote_control_item, null);
            holder.deviceName_tv = (TextView) convertView.findViewById(R.id.deviceName_tv);
            holder.switch1_tb = (ToggleButton) convertView.findViewById(R.id.switch1_tb);
            holder.switch2_tb = (ToggleButton) convertView.findViewById(R.id.switch2_tb);
            holder.meterValue_tv = (TextView) convertView.findViewById(R.id.meterValue_tv);
            holder.switch1_ll = (LinearLayout) convertView.findViewById(R.id.switch1_ll);
            holder.switch2_ll = (LinearLayout) convertView.findViewById(R.id.switch2_ll);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        initViews(holder,position);
        return convertView;
    }

    private void initViews(ViewHolder holder,int position) {
        holder.deviceName_tv.setText(getName(position));
//        final ViewHolder finalHolder = holder;
        switch (getName(position)) {
            case "光照探头\n(LUX)":
            case "人体感应\n探头(次)":
                holder.switch1_ll.setVisibility(View.GONE);
                holder.switch2_ll.setVisibility(View.GONE);
                holder.meterValue_tv.setVisibility(View.VISIBLE);
                if (getStatus(position) >= 0 && getStatus(position) <= 999999) {
                    holder.meterValue_tv.setText(getStatus(position).toString());
                }
                break;
            default:
                holder.meterValue_tv.setVisibility(View.GONE);
                holder.switch1_ll.setVisibility(View.VISIBLE);
                holder.switch2_ll.setVisibility(View.VISIBLE);
//                setIconOff_ON(getName(position), holder.item_icon, getStatus(position) == 1 ? true : false);//设置ImageView的状态，设备状态
                holder.switch1_tb.setChecked(getStatus(position) == 1 ? true : false);
                holder.switch1_tb.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View view, MotionEvent motionEvent) {
                        if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                            if (allDevicesIsCtrl) {
                                loadingDialog.show();
                                HashMap<String, String> params = new HashMap<>();
                                params.put("toiletId", APPConstant.TOILETID);
                                params.put("usage", bathNameToUsage(bathDevices.getUsage()));
                                params.put("deviceType", deviceNameToDeviceType(getName(position)));
                                params.put("cmd", getStatus(position) == 1 ? "false" : "true");
                                OkHttpManager.CommonPostAsyn(WebConstant.SEND_CMD, params, new OkHttpManager.ResultCallback() {
                                    @Override
                                    public void onCallBack(OkHttpManager.State state, String result) {
                                        if (state != OkHttpManager.State.SUCCESS) {
                                            ((Activity) context).runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    ToastUtil.showShortToast(context, "操作失败：" + result);

                                                }
                                            });
                                        }

                                    }
                                });
                                new Timer().schedule(new TimerTask() {
                                    @Override
                                    public void run() {
                                        loadingDialog.dismiss();
                                    }
                                }, RemoteControlAty.DIALOG_TIME_DELAY);

                            } else {
                                ToastUtil.showShortToast(view.getContext(), "请打开远程控制总开关!");
                            }
                        }
                        return true;
                    }
                });
                holder.switch2_tb.setChecked(getIsCtrl(position));//设置ToggleButton的状态，远程控制子开关
                holder.switch2_tb.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View view, MotionEvent motionEvent) {
                        if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                            if (allDevicesIsCtrl) {
                                loadingDialog.show();
                                HashMap<String, String> params = new HashMap<>();
                                params.put("toiletId", APPConstant.TOILETID);
                                params.put("usage", bathNameToUsage(bathDevices.getUsage()));
                                params.put("deviceType", deviceNameToDeviceType(getName(position)));
                                params.put("action", getIsCtrl(position) ? "false" : "true");
                                OkHttpManager.CommonPostAsyn(WebConstant.INTO_OR_EXIT_REMOTE_CTRL, params, new OkHttpManager.ResultCallback() {
                                    @Override
                                    public void onCallBack(OkHttpManager.State state, String result) {
                                        if (state != OkHttpManager.State.SUCCESS) {
                                            ((Activity) context).runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    ToastUtil.showShortToast(context, "操作失败：" + result);

                                                }
                                            });
                                        }
                                    }
                                });
                                new Timer().schedule(new TimerTask() {
                                    @Override
                                    public void run() {
                                        loadingDialog.dismiss();
                                    }
                                }, RemoteControlAty.DIALOG_TIME_DELAY);
                            } else {
                                ToastUtil.showShortToast(view.getContext(), "请打开远程控制总开关!");
                            }
                        }
                        return true;
                    }
                });
        }
    }

    private String getName(int position) {
        return bathDevices.getDeviceNames().get(position);
    }

    /**
     * 设备开关状态，即switch1
     * @param position
     * @return
     */
    private Integer getStatus(int position) {
        return bathDevices.getDevicesStatus().get(bathDevices.getDeviceNames().get(position));
    }

    /**
     * 远程控制子开关状态，即switch2
     * @param position
     * @return
     */
    private boolean getIsCtrl(int position) {
        return bathDevices.getDevicesIsCtrl().get(bathDevices.getDeviceNames().get(position));
    }

    /**
     * deviceIconSetOff_ON 设备图片设置开或关
     * @param s       :设备的名称
     * @param icon    :要设置的ImageView
     * @param ischeck :设备的开关状态
     */
    private void setIconOff_ON(String s, ImageView icon, boolean ischeck) {
        if (s.equals("主灯") || s.equals("辅灯")) {
            if (ischeck) icon.setImageResource(R.drawable.light_on);
            else icon.setImageResource(R.drawable.light_off);
        } else if (s.equals("抽空风机")) {
            if (ischeck) icon.setImageResource(R.drawable.chou_on);
            else icon.setImageResource(R.drawable.chou_off);
        } else if (s.equals("音响")) {
            if (ischeck) icon.setImageResource(R.drawable.audio_on);
            else icon.setImageResource(R.drawable.audio_off);
        } else if (s.equals("消毒灯")) {
//            if (ischeck) icon.setImageResource(R.drawable.xiao_on);
//            else icon.setImageResource(R.drawable.xiao_off);
        } else if (s.equals("地面冲洗")) {
            if (ischeck) icon.setImageResource(R.drawable.floor_on);
            else icon.setImageResource(R.drawable.floor_off);
        } else if (s.equals("语音提示")) {
            if (ischeck) icon.setImageResource(R.drawable.voice_on);
            else icon.setImageResource(R.drawable.voice_off);
        } else if (s.equals("风幕机")) {
            if (ischeck) icon.setImageResource(R.drawable.wind_on);
            else icon.setImageResource(R.drawable.wind_off);
        } else if (s.equals("人工按键")) {
            if (ischeck) icon.setImageResource(R.drawable.manaulbtn_on);
            else icon.setImageResource(R.drawable.manaulbtn_off);
        }
    }

    /**
     * 远程控制的ViewHolder 内部类
     */
    public class ViewHolder_RemoteControlItem {
        public TextView name;
        public ImageView item_icon;
        public ToggleButton item_tb;
        public TextView item_tv;
    }

    /**
     * 远程控制的ViewHolder 内部类
     */
    public class ViewHolder {
        public TextView deviceName_tv;
        public ToggleButton switch1_tb;
        public ToggleButton switch2_tb;
        public TextView meterValue_tv;

        public LinearLayout switch1_ll, switch2_ll;

    }
}




