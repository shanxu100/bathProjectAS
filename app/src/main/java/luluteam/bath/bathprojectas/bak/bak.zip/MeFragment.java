package luluteam.bath.bathprojectas.bak;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import luluteam.bath.bathprojectas.R;
import luluteam.bath.bathprojectas.activity.UpdateActivity;

/**
 * Created by luluteam on 2017/10/23.
 */
@Deprecated
public class MeFragment extends Fragment {

    private RelativeLayout about_rl, checkUpdate_rl;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_me, container, false);
        initUI(view);
        return view;
    }

    private void initUI(View view) {
        about_rl = (RelativeLayout) view.findViewById(R.id.about_rl);
        checkUpdate_rl = (RelativeLayout) view.findViewById(R.id.checkUpdate_rl);
        checkUpdate_rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent updateIntent=new Intent(getActivity(), UpdateActivity.class);
                startActivity(updateIntent);
            }
        });
    }



}


