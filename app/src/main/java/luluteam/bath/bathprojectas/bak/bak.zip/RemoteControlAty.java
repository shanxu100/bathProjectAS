package luluteam.bath.bathprojectas.bak;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import luluteam.bath.bathprojectas.R;
import luluteam.bath.bathprojectas.activity.BaseActivity;
import luluteam.bath.bathprojectas.constants.APPConstant;
import luluteam.bath.bathprojectas.constants.WebConstant;
import luluteam.bath.bathprojectas.model.RemoteControl.AllDevicesMessage;
import luluteam.bath.bathprojectas.model.RemoteControl.DeviceMessage;
import luluteam.bath.bathprojectas.model.RemoteControl.RemoteCtrlDevices;
import luluteam.bath.bathprojectas.tools.EventBusManager;
import luluteam.bath.bathprojectas.utils.ClickUtil;
import luluteam.bath.bathprojectas.utils.OkHttpManager;
import luluteam.bath.bathprojectas.utils.ToastUtil;
import luluteam.bath.bathprojectas.view.dialog.LoadingDialog;

import static luluteam.bath.bathprojectas.utils.deviceTransformUtil.deviceTypeTodeviceName;
import static luluteam.bath.bathprojectas.utils.deviceTransformUtil.usageToBathName;

@SuppressWarnings("all")
public class RemoteControlAty extends BaseActivity implements View.OnTouchListener {
    private RemoteCtrlDevices manBathDevice = new RemoteCtrlDevices("男厕");
    private RemoteCtrlDevices womanBathDevice = new RemoteCtrlDevices("女厕");
    private RemoteCtrlDevices disableBathDevice = new RemoteCtrlDevices("残卫");
    private CommonDeviceCtrlFragment fragment = new CommonDeviceCtrlFragment();

    private boolean allDeviceIsCtrl = false;//远程控制或者禁止远程控制的总开关状态


    private ToggleButton ctrlAllBtn;//远程控制总开关
    private Button refreshState_btn;//刷新按钮
    private Toolbar toolbar;
    private TextView toolbar_title_tv;
    private ImageView toolbar_function_iv;
    private RelativeLayout netstate_rl;

    private ViewPager remoteCtrl_viewpager;
    private TabLayout remoteCtrl_tablayout;
    private List<String> titleList = new ArrayList<>();
    private List<RemoteCtrlFragment> fragmentList = new ArrayList<>();

    //    private LoadingDialog loadingDialog;
    public static final int DIALOG_TIME_DELAY = 2500;

    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remote_control);
        context = this;
        initUI();
        initData();
        //刷新
        doRefresh();
        setEventBus(this, true);
    }

    /**
     * 初始化UI界面
     */
    private void initUI() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar_title_tv = (TextView) findViewById(R.id.toolbar_title_tv);
        toolbar_function_iv = (ImageView) findViewById(R.id.toolbar_function_iv);
        ctrlAllBtn = (ToggleButton) findViewById(R.id.ctrAllBtn);
        refreshState_btn = (Button) findViewById(R.id.refreshState_btn);//获取当前设备状态的按钮
        netstate_rl = (RelativeLayout) findViewById(R.id.netstate_rl);

        remoteCtrl_tablayout = (TabLayout) findViewById(R.id.remoteCtrl_tab);
        remoteCtrl_viewpager = (ViewPager) findViewById(R.id.container);

        toolbar_function_iv.setVisibility(View.GONE);
        setActionBar();

        ctrlAllBtn.setOnTouchListener(this);
        refreshState_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doRefresh();
            }
        });
    }

    /**
     * 初始化数据
     */
    private void initData() {
        ArrayList<String> deviceNames = new ArrayList<>();
        for (char i = 'A'; i < 'L'; i++) {
            if (i >= 'F' && i <= 'H') continue;
            deviceNames.add(deviceTypeTodeviceName(i));
        }
        deviceNames.remove(deviceTypeTodeviceName('K'));
        manBathDevice.setDeviceNames(deviceNames);
        womanBathDevice.setDeviceNames(deviceNames);
        disableBathDevice.setDeviceNames(deviceNames);
        for (int j = 1; j <= 3; j++) {
            HashMap<String, Integer> hashMap = new HashMap<>();
            HashMap<String, Boolean> hashMapCtrl = new HashMap<>();
            RemoteCtrlFragment fragment = new RemoteCtrlFragment();
            for (char i = 'A'; i <= 'K'; i++) {
                if (i >= 'F' && i <= 'H') continue;
                hashMap.put(deviceTypeTodeviceName(i), 0);
                hashMapCtrl.put(deviceTypeTodeviceName(i), false);
            }
            switch (j) {
                case 1:
                    manBathDevice.setDevicesStatus(hashMap, hashMapCtrl);
                    fragment.setAdapter(new RemoteControlAdapter(this, manBathDevice, allDeviceIsCtrl));
                case 2:
                    womanBathDevice.setDevicesStatus(hashMap, hashMapCtrl);
                    fragment.setAdapter(new RemoteControlAdapter(this, womanBathDevice, allDeviceIsCtrl));
                case 3:
                    disableBathDevice.setDevicesStatus(hashMap, hashMapCtrl);
                    fragment.setAdapter(new RemoteControlAdapter(this, disableBathDevice, allDeviceIsCtrl));
            }
            titleList.add(usageToBathName(j));
            fragment.setUsage(usageToBathName(j));
            fragmentList.add(fragment);
        }
        titleList.add("公用");
        fragment.setUsage("公用");
        fragmentList.add(fragment);
        remoteCtrl_viewpager.setAdapter(new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                return fragmentList.get(position);
            }

            @Override
            public int getCount() {
                return fragmentList.size();
            }

            @Override
            public CharSequence getPageTitle(int position) {
                return titleList.get(position);
            }
        });
        remoteCtrl_tablayout.setupWithViewPager(remoteCtrl_viewpager);
    }

    /**
     * （取消）注册 EventBus
     *
     * @param context
     * @param action
     */
    private void setEventBus(Context context, boolean action) {
        if (action) {
            if (!EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.RemoteControl).isRegistered(context)) {
                EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.RemoteControl).register(context);
            }
            if (!EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.Broadcast).isRegistered(context)) {
                EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.Broadcast).register(context);
            }
        } else {
            EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.RemoteControl).unregister(context);
            EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.Broadcast).unregister(context);
        }
    }

    /**
     * 显示toolbar
     */
    private void setActionBar() {
        toolbar.setVisibility(View.GONE);
//        toolbar_title_tv.setText("远程控制");
//        toolbar.setTitle("");
//        this.setSupportActionBar(toolbar);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    /**
     * 刷新：获取整体状态
     */
    private void doRefresh() {
        LoadingDialog loadingDialog = new LoadingDialog(context);
        loadingDialog.setCanceledOnTouchOutside(false);
        loadingDialog.setLoadingText("正在更新数据");
        loadingDialog.show();
        HashMap<String, String> params = new HashMap<>();
        params.put("toiletId", APPConstant.TOILETID);
        OkHttpManager.CommonPostAsyn(WebConstant.GET_CURRENT_STATER, params, new OkHttpManager.ResultCallback() {
            @Override
            public void onCallBack(OkHttpManager.State state, String result) {
                System.out.println("获取当整体状态:" + result);
                if (state != OkHttpManager.State.SUCCESS) {
                    RemoteControlAty.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            ToastUtil.showShortToast(context, "操作失败：" + result);
                        }
                    });
                }
            }
        });
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                loadingDialog.dismiss();
            }
        }, RemoteControlAty.DIALOG_TIME_DELAY);
    }

    @Override
    protected void onDestroy() {
//        EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.RemoteControl).unregister(this);
        setEventBus(this, false);
        super.onDestroy();
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
            switch (view.getId()) {
                case R.id.ctrAllBtn: {
                    LoadingDialog loadingDialog = new LoadingDialog(context);
                    loadingDialog.setCanceledOnTouchOutside(false);
                    loadingDialog.setLoadingText("正在更新数据");
                    loadingDialog.show();
                    HashMap<String, String> params = new HashMap<>();
                    params.put("toiletId", APPConstant.TOILETID);
//                    params.put("action", ((SwitchButton) view).isChecked() ? "false" : "true");
                    params.put("action", allDeviceIsCtrl ? "false" : "true");
                    OkHttpManager.CommonPostAsyn(WebConstant.INTO_OR_EXIT_REMOTE_CTRL, params, new OkHttpManager.ResultCallback() {
                        @Override
                        public void onCallBack(OkHttpManager.State state, String result) {
                            if (state != OkHttpManager.State.SUCCESS) {
                                RemoteControlAty.this.runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        ToastUtil.showShortToast(context, "操作失败：" + result);
                                    }
                                });
                            }
                        }
                    });
                    new Timer().schedule(new TimerTask() {
                        @Override
                        public void run() {
                            loadingDialog.dismiss();
                        }
                    }, DIALOG_TIME_DELAY);
                }
                break;
            }
        }
        return true;
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        /**
         * 对返回键做了修改
         */
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            doBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * 退出Activity
     */
    private void doBack() {
        if (allDeviceIsCtrl) {
            ToastUtil.showLongToast(context, "请先退出远程控制状态");
        } else {
            if (ClickUtil.isFastDoubleClick()) {
                finish();
            } else {
                ToastUtil.showShortToast(context, "再按一次返回键退出");
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN, priority = 100)
    public void onEventBusMessage(EventBusManager.EventBusMsg msg) {
        if (msg.msgType == EventBusManager.MsgType.fromServer) {
            if (msg.getFlag() == 0) {
                setOneDeviceStatus(msg.getDeviceMessage());
            } else if (msg.getFlag() == 1) {
                setAllDeviceStatus(msg.getAllDevicesMessage());
            }
        } else if (msg.msgType == EventBusManager.MsgType.fromWebSocket) {
            if (msg.isAction()) {
                //websocket已连接
                netstate_rl.setVisibility(View.GONE);
            } else {
                //websocket已断开
                netstate_rl.setVisibility(View.VISIBLE);
            }
        }

    }

    private void setAllDeviceStatus(AllDevicesMessage allDevicesMessage) {
        if (allDevicesMessage != null) {
            manBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('A'), allDevicesMessage.isAction_M_MainLight() ? 1 : 0);
            manBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('B'), allDevicesMessage.isAction_M_SecondaryLight() ? 1 : 0);
            manBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('C'), allDevicesMessage.isAction_M_AirPump() ? 1 : 0);
            manBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('D'), allDevicesMessage.isAction_M_Audio() ? 1 : 0);
            manBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('E'), allDevicesMessage.isAction_M_Sterilamp() ? 1 : 0);
            manBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('I'), allDevicesMessage.isControlled_M_WindMachine() ? 1 : 0);
            manBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('J'), allDevicesMessage.getValue_M_lightDetector());
//            manBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('K'), allDevicesMessage.getValue_M_bodyDetector());
            manBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('A'), allDevicesMessage.isControlled_M_MainLight());
            manBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('B'), allDevicesMessage.isControlled_M_SecondaryLight());
            manBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('C'), allDevicesMessage.isControlled_M_AirPump());
            manBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('D'), allDevicesMessage.isControlled_M_Audio());
            manBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('E'), allDevicesMessage.isControlled_M_Sterilamp());
            manBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('I'), allDevicesMessage.isControlled_M_WindMachine());

            womanBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('A'), allDevicesMessage.isAction_W_MainLight() ? 1 : 0);
            womanBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('B'), allDevicesMessage.isAction_W_SecondaryLight() ? 1 : 0);
            womanBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('C'), allDevicesMessage.isAction_W_AirPump() ? 1 : 0);
            womanBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('D'), allDevicesMessage.isAction_W_Audio() ? 1 : 0);
            womanBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('E'), allDevicesMessage.isAction_W_Sterilamp() ? 1 : 0);
            womanBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('I'), allDevicesMessage.isAction_W_WindMachine() ? 1 : 0);
            womanBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('J'), allDevicesMessage.getValue_W_lightDetector());
//            womanBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('K'), allDevicesMessage.getValue_W_bodyDetector());
            womanBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('A'), allDevicesMessage.isControlled_W_MainLight());
            womanBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('B'), allDevicesMessage.isControlled_W_SecondaryLight());
            womanBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('C'), allDevicesMessage.isControlled_W_AirPump());
            womanBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('D'), allDevicesMessage.isControlled_W_Audio());
            womanBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('E'), allDevicesMessage.isControlled_W_Sterilamp());
            womanBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('I'), allDevicesMessage.isControlled_W_WindMachine());

            disableBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('A'), allDevicesMessage.isAction_D_MainLight() ? 1 : 0);
            disableBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('B'), allDevicesMessage.isAction_D_SecondaryLight() ? 1 : 0);
            disableBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('C'), allDevicesMessage.isAction_D_AirPump() ? 1 : 0);
            disableBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('D'), allDevicesMessage.isAction_D_Audio() ? 1 : 0);
            disableBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('E'), allDevicesMessage.isAction_D_Sterilamp() ? 1 : 0);
            disableBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('I'), allDevicesMessage.isAction_D_WindMachine() ? 1 : 0);
            disableBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('J'), allDevicesMessage.getValue_D_lightDetector());
//            disableBathDevice.getDevicesStatus().put(deviceTypeTodeviceName('K'), allDevicesMessage.getValue_D_bodyDetector());
            disableBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('A'), allDevicesMessage.isControlled_D_MainLight());
            disableBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('B'), allDevicesMessage.isControlled_D_SecondaryLight());
            disableBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('C'), allDevicesMessage.isControlled_D_AirPump());
            disableBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('D'), allDevicesMessage.isControlled_D_Audio());
            disableBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('E'), allDevicesMessage.isControlled_D_Sterilamp());
            disableBathDevice.getDevicesIsCtrl().put(deviceTypeTodeviceName('I'), allDevicesMessage.isControlled_D_WindMachine());

            allDeviceIsCtrl = allDevicesMessage.isControlled();
            ctrlAllBtn.setChecked(allDeviceIsCtrl);
//            ctrlAllBtn.refreshDrawableState();
//            ctrlAllBtn.setChecked(allDeviceIsCtrl);

//            ToastUtil.showLongToast(context,"allDeviceIsCtrl"+allDeviceIsCtrl+" "+ctrlAllBtn.isChecked());
            for (RemoteCtrlFragment fragment : fragmentList) {
                if (manBathDevice.getUsage() == fragment.getUsage()) {
                    fragment.onStateChange(manBathDevice, allDeviceIsCtrl);
                } else if (womanBathDevice.getUsage() == fragment.getUsage()) {
                    fragment.onStateChange(womanBathDevice, allDeviceIsCtrl);
                } else if (disableBathDevice.getUsage() == fragment.getUsage()) {
                    fragment.onStateChange(disableBathDevice, allDeviceIsCtrl);
                } else if (fragment.getUsage().equals("公用")) {
                    ((CommonDeviceCtrlFragment)fragment).setAllDeviceIsCtrl(allDeviceIsCtrl);
                    ((CommonDeviceCtrlFragment)fragment).setElecMeterTvValue(allDevicesMessage.getValue_C_ElecMeter().toString());
                    ((CommonDeviceCtrlFragment)fragment).setWaterMeterTvValue(allDevicesMessage.getValue_C_WaterMeter().toString());
                    ((CommonDeviceCtrlFragment)fragment).setVoiceCtrlTb1(allDevicesMessage.isAction_C_VoiceGuide());
                    ((CommonDeviceCtrlFragment)fragment).setVoiceCtrlTb2(allDevicesMessage.isControlled_C_VoiceGuid());
                }
            }
        }
    }

    private void setOneDeviceStatus(DeviceMessage deviceMessage) {
        if (deviceMessage != null) {
            String name = deviceTypeTodeviceName(deviceMessage.getDeviceType().charAt(0));
            String usage = usageToBathName(deviceMessage.getUsage());
            if (1 == deviceMessage.getUsage()) {
                manBathDevice.getDevicesStatus().put(name, deviceMessage.isAction() ? 1 : 0);
            } else if (2 == deviceMessage.getUsage()) {
                womanBathDevice.getDevicesStatus().put(name, deviceMessage.isAction() ? 1 : 0);
            } else if (3 == deviceMessage.getUsage()) {
                disableBathDevice.getDevicesStatus().put(name, deviceMessage.isAction() ? 1 : 0);
            }else if (4==deviceMessage.getUsage())
            {
                fragment.setVoiceCtrlTb1(deviceMessage.isAction());
            }
            for (RemoteCtrlFragment fragment : fragmentList) {
                if (fragment.getUsage().equals(usage)) {
                    if (usage.equals("男厕")) {
                        fragment.onStateChange(manBathDevice, allDeviceIsCtrl);
                    } else if (usage.equals("女厕")) {
                        fragment.onStateChange(womanBathDevice, allDeviceIsCtrl);
                    } else if (usage.equals("残卫")) {
                        fragment.onStateChange(disableBathDevice, allDeviceIsCtrl);
                    } else if (usage.equals("公用")) {
                        fragment.setMenuVisibility(deviceMessage.isAction());
                    }
                    break;
                }
            }
        }
    }

    /**
     * 定义回调函数用来实时改变数据
     */
    public interface RecordInfoCallback {
        void onStateChange(RemoteCtrlDevices devices, boolean ctrlOrNotCtrl);
    }
}
