package luluteam.bath.bathprojectas.bak;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import luluteam.bath.bathprojectas.R;
import luluteam.bath.bathprojectas.activity.BaseActivity;
import luluteam.bath.bathprojectas.constants.APPConstant;
import luluteam.bath.bathprojectas.fragment.statistics.UsageAmoutFragment;
import luluteam.bath.bathprojectas.fragment.statistics.UsageDurationFragment;
import luluteam.bath.bathprojectas.fragment.statistics.UsageTimesFragment;
import luluteam.bath.bathprojectas.utils.ClickUtil;
import luluteam.bath.bathprojectas.utils.SharedPreferencesUtil;
import luluteam.bath.bathprojectas.utils.ToastUtil;
import luluteam.bath.bathprojectas.view.dialog.ChooseUsageDialog;

/**
 * 统计分析
 */
@Deprecated
public class StatisticActivity extends BaseActivity {

    private final static String TAG = "StatisticActivity";

    private TabLayout statistics_tablayout;
    private ViewPager statistics_viewpager;
    private TextView nowToiletId_tv;
    private TextView nowToiletType_tv;
    private FragmentManager fragmentManager;
    private List<Fragment> fragmentList = new ArrayList<>();
    private List<String> titleList = new ArrayList<>();

    private Toolbar toolbar;

    private TextView toolbar_title_tv;
    private ImageView toolbar_function_iv;

    private UsageDurationFragment durationFragment;
    private UsageTimesFragment timesFragment;
    private UsageAmoutFragment amoutFragment;

    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistic);
        this.context = this;
        initData();
        initUI();

    }

    private void initData() {

        durationFragment = new UsageDurationFragment();
        timesFragment = new UsageTimesFragment();
        amoutFragment = new UsageAmoutFragment();


        fragmentManager = getSupportFragmentManager();

        fragmentList.add(durationFragment);
        fragmentList.add(timesFragment);
        fragmentList.add(amoutFragment);

        titleList.add("时间统计");
        titleList.add("次数统计");
        titleList.add("用量统计");


    }

    private void initUI() {
        statistics_tablayout = (TabLayout) findViewById(R.id.statistics_tab);
        statistics_viewpager = (ViewPager) findViewById(R.id.statistics_viewpager);
        nowToiletId_tv = (TextView) findViewById(R.id.nowToiletId);
        nowToiletType_tv = (TextView) findViewById(R.id.nowToiletType);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar_title_tv = (TextView) findViewById(R.id.toolbar_title_tv);
        toolbar_function_iv = (ImageView) findViewById(R.id.toolbar_function_iv);
        showToiletInfo();
        setActionBar();
        //加上可见的fragment，另外保留另外两个不可见fragment不销毁
        statistics_viewpager.setOffscreenPageLimit(2);

        statistics_viewpager.setAdapter(new FragmentPagerAdapter(fragmentManager) {
            @Override
            public Fragment getItem(int position) {
                return fragmentList.get(position);
            }

            @Override
            public int getCount() {
                return fragmentList.size();
            }

            @Override
            public CharSequence getPageTitle(int position) {
                return titleList.get(position);
            }
        });

        statistics_tablayout.setupWithViewPager(statistics_viewpager);
    }

    /**
     * 设置toolbar
     */
    private void setActionBar() {
        toolbar_title_tv.setText("统计分析");

        this.setSupportActionBar(toolbar);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        this.getSupportActionBar().setDisplayShowTitleEnabled(true);
//        this.getSupportActionBar().setTitle("");

        toolbar_function_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChooseUsageDialog dialog = new ChooseUsageDialog(context);
                dialog.show();
                dialog.setClickSureBtnListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String usage = dialog.getCheckedUsage();
                        SharedPreferencesUtil.putString(context, "usage", usage);
                        APPConstant.USAG = usage;
                        dialog.dismiss();
                        showToiletInfo();
                        durationFragment.setChart();
                        timesFragment.setChart();
                    }
                });
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            doBack();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * 显示当前厕所ID
     */
    private void showToiletInfo() {
        nowToiletId_tv.setText(APPConstant.TOILETID);
        switch (APPConstant.USAG) {
            case "1":
                nowToiletType_tv.setText("男厕");
                break;
            case "2":
                nowToiletType_tv.setText("女厕");
                break;
            case "3":
                nowToiletType_tv.setText("残卫");
                break;
            default:
                nowToiletType_tv.setText(APPConstant.USAG);
        }
    }

    /**
     * 退出Activity
     */
    private void doBack() {
        if (ClickUtil.isFastDoubleClick()) {
            finish();
        } else {
            ToastUtil.showShortToast(context, "再按一次返回键退出");
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        /**
         * 对返回键做了修改
         */
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            doBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

}
