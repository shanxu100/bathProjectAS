package luluteam.bath.bathprojectas.bak;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.apache.commons.lang.StringUtils;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import luluteam.bath.bathprojectas.R;
import luluteam.bath.bathprojectas.activity.BaseActivity;
import luluteam.bath.bathprojectas.activity.PermissionActivity;
import luluteam.bath.bathprojectas.activity.UpdateActivity;
import luluteam.bath.bathprojectas.constants.APPConstant;
import luluteam.bath.bathprojectas.services.floatwindow.FloatWindowSimpleService;
import luluteam.bath.bathprojectas.services.mqtt.MqttService;
import luluteam.bath.bathprojectas.services.websocket.WebSocketClient;
import luluteam.bath.bathprojectas.services.websocket.WebSocketService;
import luluteam.bath.bathprojectas.tools.EventBusManager;
import luluteam.bath.bathprojectas.utils.ClickUtil;
import luluteam.bath.bathprojectas.utils.SharedPreferencesUtil;
import luluteam.bath.bathprojectas.utils.ToastUtil;
import luluteam.bath.bathprojectas.view.dialog.ChooseToiletIdDialog;


@Deprecated
public class MainActivity extends BaseActivity {

    //    private Spinner mSpinner;
    private ImageView functioniv, meiv;
    private TextView functiontv, metv, toolbar_title_tv, nowToiletId_tv;
    private RelativeLayout functiontab, metab;
    private Toolbar toolbar;
    private ImageView toolbar_function_iv;

    private FunctionFragment functionFragment;
    private MeFragment meFragment;

    private FragmentTransaction transaction;
    private FragmentManager manager;

    private DrawerLayout drawerLayout;

    private Intent websocketIntent;
    private Intent mqttIntent;
    private Intent networkStateIntent;

    private LinearLayout websocketstate_ll, mqttstate_ll;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        manager = getSupportFragmentManager();
        initView();
        initData();
        changeFragment(0);
        if (!EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.Broadcast).isRegistered(this)) {
            EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.Broadcast).register(this);
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        showToiletInfo();
//        checkPermissions();
    }

    /**
     * 初始化
     */
    private void initView() {
        context = MainActivity.this;
        functioniv = (ImageView) findViewById(R.id.functioniv);
        meiv = (ImageView) findViewById(R.id.meiv);

        functiontv = (TextView) findViewById(R.id.functiontv);
        metv = (TextView) findViewById(R.id.metv);

        functiontab = (RelativeLayout) findViewById(R.id.functiontab);
        metab = (RelativeLayout) findViewById(R.id.metab);
        websocketstate_ll = (LinearLayout) findViewById(R.id.websocketstate_ll);
        mqttstate_ll = (LinearLayout) findViewById(R.id.mqttstate_ll);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar_function_iv = (ImageView) findViewById(R.id.toolbar_function_iv);
        toolbar_title_tv = (TextView) findViewById(R.id.toolbar_title_tv);

        nowToiletId_tv = (TextView) findViewById(R.id.nowToiletId_tv);

        functiontab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeFragment(0);
            }
        });
        metab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeFragment(1);
            }
        });

        setActionBar();
    }

    private void initData() {
        /**
         * 开启各种service
         */
        websocketIntent = new Intent(this, WebSocketService.class);
        mqttIntent = new Intent(this, MqttService.class);
        networkStateIntent = new Intent(this, FloatWindowSimpleService.class);
        startService(websocketIntent);
        startService(mqttIntent);
        startService(networkStateIntent);
        checkPermissions();
        checkUpdate();

    }

    /**
     * 设置ActionBar的样式，以及添加的一些功能
     */
    private void setActionBar() {

        toolbar_title_tv.setText("克劳迪智能卫浴");
        toolbar.setTitle("");

        this.setSupportActionBar(toolbar);
        toolbar_function_iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChooseToiletIdDialog dialog = new ChooseToiletIdDialog(context);
                dialog.show();
                dialog.setClickSureBtnListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        APPConstant.TOILETID = dialog.getSelectedToiletId();
                        SharedPreferencesUtil.putString(context, "toiletId", APPConstant.TOILETID);
                        WebSocketClient.getInstance().sendMsg(APPConstant.TOILETID);
                        showToiletInfo();
                        dialog.dismiss();
                    }
                });
            }
        });



    }

    private void showToiletInfo() {
        if (StringUtils.isEmpty(APPConstant.TOILETID)) {
            nowToiletId_tv.setText("请选择 ToiletId");
        } else {
            nowToiletId_tv.setText(APPConstant.TOILETID);
        }
    }

    /**
     * 根据index值选择展示的fragment
     *
     * @param index
     */
    private void changeFragment(int index) {
        transaction = manager.beginTransaction();
        hideFragment(transaction);
        changeStyle(index);
        switch (index) {
            case 0:
                if (functionFragment == null) {
                    functionFragment = new FunctionFragment();
                    transaction.add(R.id.mainfrag, functionFragment);
                } else
                    transaction.show(functionFragment);
                break;
            case 1:
                if (meFragment == null) {
                    meFragment = new MeFragment();
                    transaction.add(R.id.mainfrag, meFragment);
                } else
                    transaction.show(meFragment);
                break;
        }
        transaction.commit();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                drawerLayout.openDrawer(Gravity.START);
                break;
        }
        return true;
    }

    @Subscribe(threadMode = ThreadMode.MAIN, priority = 100)
    public void onEventBusMessage(EventBusManager.EventBusMsg msg) {
//        if (msg.msgType == EventBusManager.MsgType.fromWebSocket) {
//            if (msg.isAction()) {
//                websocketstate_ll.setVisibility(View.GONE);
//            } else {
//                websocketstate_ll.setVisibility(View.VISIBLE);
//            }
//        } else if (msg.msgType == EventBusManager.MsgType.fromMqtt) {
//            if (msg.isAction()) {
//                mqttstate_ll.setVisibility(View.GONE);
//            } else {
//                mqttstate_ll.setVisibility(View.VISIBLE);
//            }
//        }

    }

    /**
     * 更改tab中文本和图像的样式
     *
     * @param index
     */
    private void changeStyle(int index) {
        switch (index) {
            case 0:
                functioniv.setImageResource(R.drawable.function_sel);
                meiv.setImageResource(R.drawable.mine_nor);

                functiontv.setTextColor(getResources().getColor(R.color.green));
                metv.setTextColor(getResources().getColor(R.color.gray));
                break;

            case 1:
                functioniv.setImageResource(R.drawable.function_nor);
                meiv.setImageResource(R.drawable.mine_sel);

                functiontv.setTextColor(getResources().getColor(R.color.gray));
                metv.setTextColor(getResources().getColor(R.color.green));
                break;
        }
    }

    /**
     * 将已加入的fragment全部隐藏
     *
     * @param transaction
     */
    private void hideFragment(FragmentTransaction transaction) {
        if (functionFragment != null) {
            transaction.hide(functionFragment);
        }

        if (meFragment != null) {
            transaction.hide(meFragment);
        }
    }

    /**
     * 检查权限
     */
    private void checkPermissions() {
        Intent permissionIntent = new Intent(this, PermissionActivity.class);
        startActivity(permissionIntent);
    }

    private void checkAndMakeDir() {
        boolean hasPermission = (ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED);
        if (!hasPermission)
        {
            return;
        }

    }

    /**
     * 检查更新
     */
    private void checkUpdate()
    {
        Intent intent=new Intent(this,UpdateActivity.class);
        startActivity(intent);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.Broadcast).unregister(this);
        stopService(websocketIntent);
        stopService(mqttIntent);
        stopService(networkStateIntent);
    }

    /**
     * 退出Activity
     */
    @Override
    public void onBackPressed() {
        if (ClickUtil.isFastDoubleClick()) {
            moveTaskToBack(true);
        } else {
            ToastUtil.showShortToast(context, "再按一次程序返回后台运行");
        }
    }
}
