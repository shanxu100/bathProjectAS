package luluteam.bath.bathprojectas.bak;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import org.apache.commons.lang.StringUtils;

import java.util.HashMap;

import luluteam.bath.bathprojectas.R;
import luluteam.bath.bathprojectas.bak.ManageSetAty;
import luluteam.bath.bathprojectas.bak.StatisticActivity;
import luluteam.bath.bathprojectas.app.App;
import luluteam.bath.bathprojectas.bak.ControlActivity;
import luluteam.bath.bathprojectas.constants.APPConstant;
import luluteam.bath.bathprojectas.constants.WebConstant;
import luluteam.bath.bathprojectas.utils.OkHttpManager;
import luluteam.bath.bathprojectas.utils.ToastUtil;

/**
 * Created by luluteam on 2017/11/30.
 */
@Deprecated
public class FunctionFragment extends Fragment implements View.OnClickListener {

    public static String TAG = "FunctionFragment";
    private RelativeLayout mRemoteCtrBtn;
    private RelativeLayout mStaticAnalysisBtn;
    private RelativeLayout mManageSetBtn;
    private RelativeLayout exit_rl;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_function, container, false);

        mRemoteCtrBtn = (RelativeLayout) view.findViewById(R.id.RemoteCtrBtn);
        mStaticAnalysisBtn = (RelativeLayout) view.findViewById(R.id.StaticAnalysisBtn);
        mManageSetBtn = (RelativeLayout) view.findViewById(R.id.ManageSetBtn);
        exit_rl = (RelativeLayout) view.findViewById(R.id.Exit_rl);

        mRemoteCtrBtn.setOnClickListener(this);
        mStaticAnalysisBtn.setOnClickListener(this);
        mManageSetBtn.setOnClickListener(this);
        exit_rl.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.Exit_rl) {
            /**
             * 通知服务器,user退出
             */
            HashMap<String,String> params=new HashMap<>();
            params.put("username",APPConstant.USERNAME);
            OkHttpManager.CommonPostAsyn(WebConstant.LOGOUT, params, new OkHttpManager.ResultCallback() {
                @Override
                public void onCallBack(OkHttpManager.State state, String result) {

                }
            });
            App.Logout();
            return;
        }
        if (StringUtils.isEmpty(APPConstant.TOILETID)) {
            ToastUtil.showLongToast(getContext(), "请选择 ToiletId ");
            return;
        }
        switch (v.getId()) {
            case R.id.RemoteCtrBtn:
                startActivity(new Intent(getActivity(), ControlActivity.class));
                break;
            case R.id.StaticAnalysisBtn:
                startActivity(new Intent(getActivity(), StatisticActivity.class));
                break;
            case R.id.ManageSetBtn:
                startActivity(new Intent(getActivity(), ManageSetAty.class));
                break;
        }
    }
}
