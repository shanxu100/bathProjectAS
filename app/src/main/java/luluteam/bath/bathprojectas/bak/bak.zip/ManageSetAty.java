package luluteam.bath.bathprojectas.bak;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import luluteam.bath.bathprojectas.R;
import luluteam.bath.bathprojectas.activity.BaseActivity;
import luluteam.bath.bathprojectas.constants.APPConstant;
import luluteam.bath.bathprojectas.fragment.setting.DeviceSettingFragment;
import luluteam.bath.bathprojectas.fragment.setting.ToiletManageFragment;
import luluteam.bath.bathprojectas.fragment.setting.UserManageFragment;
import luluteam.bath.bathprojectas.model.ParamsInfo;
import luluteam.bath.bathprojectas.tools.EventBusManager;
import luluteam.bath.bathprojectas.utils.ClickUtil;
import luluteam.bath.bathprojectas.utils.ToastUtil;


/**
 * 管理设置功能
 */
@Deprecated
public class ManageSetAty extends BaseActivity {


    private FragmentManager fragmentManager;
    private ViewPager manageSet_viewpager;
    private TabLayout manageSet_tablayout;

    private Toolbar toolbar;

    private TextView toolbar_title_tv;
    private ImageView toolbar_function_iv;

    private RelativeLayout netstate_rl;

    private TextView nowToiletId_tv;
    //    private TextView nowToiletType_tv;
    private List<String> titleList = new ArrayList<>();
    private List<Fragment> fragmentList = new ArrayList<>();

    //    private DeviceSetFragment deviceSetFragment;
    private DeviceSettingFragment deviceSettingFragment;
    private UserManageFragment userManageFragment;
    private ToiletManageFragment toiletManageFragment;

    /**
     * 用于存储websocket传来的数据，分为男厕，女厕，殘卫三种情况存储
     */
    private HashMap<String, HashMap<String, String>> params;
    /**
     * websocket 的采集卡的系统时间
     */
    private String time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_set_aty);
        initUI();
        initData();
        setEventBus(this, true);

    }

    private void initUI() {
        manageSet_tablayout = (TabLayout) findViewById(R.id.manageSet_tab);
        manageSet_viewpager = (ViewPager) findViewById(R.id.container);
        nowToiletId_tv = (TextView) findViewById(R.id.nowToiletId);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar_title_tv = (TextView) findViewById(R.id.toolbar_title_tv);
        toolbar_function_iv = (ImageView) findViewById(R.id.toolbar_function_iv);
        netstate_rl = (RelativeLayout) findViewById(R.id.netstate_rl);
        setToiletTextView();
        setActionBar();
    }

    private void initData() {
        fragmentManager = getSupportFragmentManager();

//        deviceSetFragment = new DeviceSetFragment();
        deviceSettingFragment = new DeviceSettingFragment();
        toiletManageFragment = new ToiletManageFragment();
        userManageFragment = new UserManageFragment();

//        fragmentList.add(deviceSetFragment);
        fragmentList.add(deviceSettingFragment);
        fragmentList.add(userManageFragment);
        fragmentList.add(toiletManageFragment);

        titleList.add("设备设置");
        titleList.add("用户管理");
        titleList.add("公厕管理");


        manageSet_viewpager.setAdapter(new FragmentPagerAdapter(fragmentManager) {
            @Override
            public Fragment getItem(int position) {
                return fragmentList.get(position);
            }

            @Override
            public int getCount() {
                return fragmentList.size();
            }

            @Override
            public CharSequence getPageTitle(int position) {
                return titleList.get(position);
            }
        });
        manageSet_tablayout.setupWithViewPager(manageSet_viewpager);
    }

    /**
     * 设置toolbar
     */
    private void setActionBar() {

        toolbar_title_tv.setText("管理设置");
        this.setSupportActionBar(toolbar);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        toolbar_function_iv.setVisibility(View.GONE);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            doBack();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setToiletTextView() {
        if (!"".equals(APPConstant.TOILETID)) {
            nowToiletId_tv.setText(APPConstant.TOILETID);
        } else {
            nowToiletId_tv.setText("12345678");
        }
    }

    /**
     * （取消）注册 EventBus
     *
     * @param context
     * @param action
     */
    private void setEventBus(Context context, boolean action) {
        if (action) {
            if (!EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.Params).isRegistered(context)) {
                EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.Params).register(context);
            }
            if (!EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.Broadcast).isRegistered(context)) {
                EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.Broadcast).register(context);
            }
        } else {
            EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.Params).unregister(context);
            EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.Broadcast).unregister(context);
        }
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEventBusMessage(EventBusManager.EventBusMsg msg) {
        System.out.println("flag=2,进行管理设置相关参数设置！");
        if (msg.msgType == EventBusManager.MsgType.fromServer) {
            if (msg.getFlag() == 2) {
                deviceSettingFragment.setParamsBySocket(msg.getParamsInfo());
            }
        }
//        else if (msg.msgType == EventBusManager.MsgType.fromWebSocket) {
//            if (msg.isAction()) {
//                //wensocket已连接
//                netstate_rl.setVisibility(View.GONE);
//            } else {
//                //wensocket已断开
//                netstate_rl.setVisibility(View.VISIBLE);
//            }
//        }
    }

    /**
     * 显示通过websocket从设备远程得到的设备相关信息
     */
    private void setDeviceParams(ParamsInfo info) {
        params = new HashMap<>();
        if (info != null) {
            time = info.getTime();
            ParamsInfo.Params value = info.getValue();
            HashMap<String, String> manParams = new HashMap<>();
            HashMap<String, String> womanParams = new HashMap<>();
            HashMap<String, String> disableParams = new HashMap<>();
            manParams.put("thresholdLight", value.getGroupMan().getThresholdLight() + "");
            manParams.put("Sterilamp_startTime", value.getGroupMan().getTimerSterilamp().getStartTime());
            manParams.put("Sterilamp_stopTime", value.getGroupMan().getTimerSterilamp().getStopTime());
            manParams.put("Sterilamp_duration", value.getGroupMan().getTimerSterilamp().getDuration_s() + "");
            manParams.put("light_startTime", value.getGroupMan().getTimerLight().getStartTime());
            manParams.put("light_stopTime", value.getGroupMan().getTimerLight().getStopTime());
            manParams.put("light_duration", value.getGroupMan().getTimerLight().getDuration_s() + "");
            manParams.put("audio_startTime", value.getGroupMan().getTimerAudio().getStartTime());
            manParams.put("audio_stopTime", value.getGroupMan().getTimerAudio().getStopTime());
            manParams.put("audio_duration", value.getGroupMan().getTimerAudio().getDuration_s() + "");

            womanParams.put("thresholdLight", value.getGroupWoman().getThresholdLight() + "");
            womanParams.put("Sterilamp_startTime", value.getGroupWoman().getTimerSterilamp().getStartTime());
            womanParams.put("Sterilamp_stopTime", value.getGroupWoman().getTimerSterilamp().getStopTime());
            womanParams.put("Sterilamp_duration", value.getGroupWoman().getTimerSterilamp().getDuration_s() + "");
            womanParams.put("light_startTime", value.getGroupWoman().getTimerLight().getStartTime());
            womanParams.put("light_stopTime", value.getGroupWoman().getTimerLight().getStopTime());
            womanParams.put("light_duration", value.getGroupWoman().getTimerLight().getDuration_s() + "");
            womanParams.put("audio_startTime", value.getGroupWoman().getTimerAudio().getStartTime());
            womanParams.put("audio_stopTime", value.getGroupWoman().getTimerAudio().getStopTime());
            womanParams.put("audio_duration", value.getGroupWoman().getTimerAudio().getDuration_s() + "");

            disableParams.put("thresholdLight", value.getGroupDisabled().getThresholdLight() + "");
            disableParams.put("Sterilamp_startTime", value.getGroupDisabled().getTimerSterilamp().getStartTime());
            disableParams.put("Sterilamp_stopTime", value.getGroupDisabled().getTimerSterilamp().getStopTime());
            disableParams.put("Sterilamp_duration", value.getGroupDisabled().getTimerSterilamp().getDuration_s() + "");
            disableParams.put("light_startTime", value.getGroupDisabled().getTimerLight().getStartTime());
            disableParams.put("light_stopTime", value.getGroupDisabled().getTimerLight().getStopTime());
            disableParams.put("light_duration", value.getGroupDisabled().getTimerLight().getDuration_s() + "");
            disableParams.put("audio_startTime", value.getGroupDisabled().getTimerAudio().getStartTime());
            disableParams.put("audio_stopTime", value.getGroupDisabled().getTimerAudio().getStopTime());
            disableParams.put("audio_duration", value.getGroupDisabled().getTimerAudio().getDuration_s() + "");

            params.put("男厕", manParams);
            params.put("女厕", womanParams);
            params.put("殘卫", disableParams);

        }
    }

    /**
     * 退出Activity
     */
    private void doBack() {
        if (ClickUtil.isFastDoubleClick()) {
            finish();
        } else {
            ToastUtil.showShortToast(ManageSetAty.this, "再按一次返回键退出");
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        /**
         * 对返回键做了修改
         */
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            doBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        setEventBus(this, false);
        super.onDestroy();
    }


    /**
     * 通知 Params 数据发生了改变
     */
    public interface ParamsCallback {
        void setParamsBySocket(ParamsInfo paramsInfo);
    }

}
