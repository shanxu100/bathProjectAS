package luluteam.bath.bathprojectas.bak;

import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;

import luluteam.bath.bathprojectas.R;
import luluteam.bath.bathprojectas.activity.BaseActivity;
import luluteam.bath.bathprojectas.fragment.BaseFragment;
import luluteam.bath.bathprojectas.fragment.main.ControlFragment;
import luluteam.bath.bathprojectas.model.RemoteControl.AllDevicesMessage;
import luluteam.bath.bathprojectas.utils.ClickUtil;
import luluteam.bath.bathprojectas.utils.ToastUtil;

//public class ControlActivity extends BaseActivity implements View.OnTouchListener, BaseFragment.ControlCallback {
public class ControlActivity extends BaseActivity implements BaseFragment.ControlCallback{

//    private Devices manDevices = new Devices("男厕");
//    private Devices womanDevices = new Devices("女厕");
//    private Devices disabledDevices = new Devices("残卫");
//
//    private RemoteControlFragment manFragment = new RemoteControlFragment();
//    private RemoteControlFragment womanFragment = new RemoteControlFragment();
//    private RemoteControlFragment disabledFragment = new RemoteControlFragment();
//    private CommonControlFragment commonFragment = new CommonControlFragment();
//
//    private ControlAdapter manAdapter;
//    private ControlAdapter womanAdapter;
//    private ControlAdapter disabledAdapter;
//
//
    private boolean allControlled = false;//远程控制或者禁止远程控制的总开关状态
//    private ToggleButton allCotrolled_btn;//远程控制总开关
//    private Button refreshState_btn;//刷新按钮
//
//    private LinearLayout websocketstate_ll, mqttstate_ll;
//
//    private ViewPager remoteCtrl_viewpager;
//    private TabLayout remoteCtrl_tablayout;
//    private List<String> titleList = new ArrayList<>();
//    private List<BaseFragment> fragmentList = new ArrayList<>();
//
    public static final int DIALOG_TIME_DELAY = 2500;
//
//    private Context context;
//    private LoadingDialog loadingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control);
        ControlFragment cf = new ControlFragment();
        FragmentTransaction transaction=getSupportFragmentManager().beginTransaction();
        transaction.add(R.id.container,cf,"test");
        transaction.commit();
//        context = this;
//        loadingDialog=new LoadingDialog(context);
//        initUI();
//        initData();
//        //刷新
//        doRefresh();
//        setEventBus(this, true);
    }

    /**
     * 初始化UI界面
     */
//    private void initUI() {
//
//        allCotrolled_btn = (ToggleButton) findViewById(R.id.allControlled_btn);
//        refreshState_btn = (Button) findViewById(R.id.refreshState_btn);//获取当前设备状态的按钮
//        websocketstate_ll = (LinearLayout) findViewById(R.id.websocketstate_ll);
//        mqttstate_ll = (LinearLayout) findViewById(R.id.mqttstate_ll);
//
//        remoteCtrl_tablayout = (TabLayout) findViewById(R.id.remoteCtrl_tab);
//        remoteCtrl_viewpager = (ViewPager) findViewById(R.id.container);
//
//        allCotrolled_btn.setOnTouchListener(this);
//        refreshState_btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                doRefresh();
//            }
//        });
//    }

    /**
     * 初始化数据
     */
//    private void initData() {
//        manAdapter = new ControlAdapter(manDevices, context);
//        womanAdapter = new ControlAdapter(womanDevices, context);
//        disabledAdapter = new ControlAdapter(disabledDevices, context);
//
//        manFragment.setUsage("男厕");
//        manFragment.setAdapter(manAdapter);
//        womanFragment.setUsage("女厕");
//        womanFragment.setAdapter(womanAdapter);
//        disabledFragment.setUsage("残卫");
//        disabledFragment.setAdapter(disabledAdapter);
//
//        titleList.add("男厕");
//        titleList.add("女厕");
//        titleList.add("残卫");
//        titleList.add("公用");
//        fragmentList.add(manFragment);
//        fragmentList.add(womanFragment);
//        fragmentList.add(disabledFragment);
//        fragmentList.add(commonFragment);
//
//
//        remoteCtrl_viewpager.setAdapter(new FragmentPagerAdapter(getSupportFragmentManager()) {
//            @Override
//            public Fragment getItem(int position) {
//                return fragmentList.get(position);
//            }
//
//            @Override
//            public int getCount() {
//                return fragmentList.size();
//            }
//
//            @Override
//            public CharSequence getPageTitle(int position) {
//                return titleList.get(position);
//            }
//        });
//        remoteCtrl_tablayout.setupWithViewPager(remoteCtrl_viewpager);
//    }

    /**
     * （取消）注册 EventBus
     *
     * @param context
     * @param action
     */
//    private void setEventBus(Context context, boolean action) {
//        if (action) {
//            if (!EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.RemoteControl).isRegistered(context)) {
//                EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.RemoteControl).register(context);
//            }
//            if (!EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.Broadcast).isRegistered(context)) {
//                EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.Broadcast).register(context);
//            }
//        } else {
//            EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.RemoteControl).unregister(context);
//            EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.Broadcast).unregister(context);
//        }
//    }


    /**
     * 刷新：获取整体状态
     */
    private void doRefresh() {
//        loadingDialog.setCanceledOnTouchOutside(false);
//        loadingDialog.setLoadingText("正在更新数据");
//        loadingDialog.show();
//        HashMap<String, String> params = new HashMap<>();
//        params.put("toiletId", APPConstant.TOILETID);
//        OkHttpManager.CommonPostAsyn(WebConstant.GET_CURRENT_STATER, params, new OkHttpManager.ResultCallback() {
//            @Override
//            public void onCallBack(OkHttpManager.State state, String result) {
//                System.out.println("获取当整体状态:" + result);
//                if (state != OkHttpManager.State.SUCCESS) {
//                    ControlActivity.this.runOnUiThread(new Runnable() {
//                        @Override
//                        public void run() {
//                            ToastUtil.showShortToast(context, "操作失败：" + result);
//                        }
//                    });
//                }
//            }
//        });
//        new Timer().schedule(new TimerTask() {
//            @Override
//            public void run() {
//                loadingDialog.dismiss();
//            }
//        }, DIALOG_TIME_DELAY);
    }


    @Override
    protected void onDestroy() {
////        EventBusManager.getInstance(EventBusManager.INSTANCE_NAME.RemoteControl).unregister(this);
//        if (loadingDialog.isShowing())
//        {
//            loadingDialog.dismiss();
//        }
//        setEventBus(this, false);
        super.onDestroy();
    }

//    @Override
//    public boolean onTouch(View view, MotionEvent motionEvent) {
//        if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
//            switch (view.getId()) {
//                case R.id.allControlled_btn: {
//                    loadingDialog.setCanceledOnTouchOutside(false);
//                    loadingDialog.setLoadingText("正在更新数据");
//                    loadingDialog.show();
//                    HashMap<String, String> params = new HashMap<>();
//                    params.put("toiletId", APPConstant.TOILETID);
////                    params.put("action", ((SwitchButton) view).isChecked() ? "false" : "true");
//                    params.put("action", allControlled ? "false" : "true");
//                    OkHttpManager.CommonPostAsyn(WebConstant.INTO_OR_EXIT_REMOTE_CTRL, params, new OkHttpManager.ResultCallback() {
//                        @Override
//                        public void onCallBack(OkHttpManager.State state, String result) {
//                            if (state != OkHttpManager.State.SUCCESS) {
//                                ControlActivity.this.runOnUiThread(new Runnable() {
//                                    @Override
//                                    public void run() {
//                                        ToastUtil.showShortToast(context, "操作失败：" + result);
//                                    }
//                                });
//                            }
//                        }
//                    });
//                    new Timer().schedule(new TimerTask() {
//                        @Override
//                        public void run() {
//                            loadingDialog.dismiss();
//                        }
//                    }, DIALOG_TIME_DELAY);
//                }
//                break;
//            }
//        }
//        return true;
//    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        /**
         * 对返回键做了修改
         */
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            doBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * 退出Activity
     */
    private void doBack() {
//        if (allControlled) {
        if (false) {
            ToastUtil.showLongToast(context, "请先退出远程控制状态");
        } else {
            if (ClickUtil.isFastDoubleClick()) {
                finish();
            } else {
                ToastUtil.showShortToast(context, "再按一次返回键退出");
            }
        }
    }

//    @Subscribe(threadMode = ThreadMode.MAIN, priority = 100)
//    public void onEventBusMessage(EventBusManager.EventBusMsg msg) {
//        if (msg.msgType == EventBusManager.MsgType.fromServer) {
//            if (msg.getFlag() == 0) {
//                //单个设备状态变化
//                setRecordInfo(msg.getDeviceMessage());
//            } else if (msg.getFlag() == 1) {
//                //全体设备状态变化
//                setWholeStateInfo(msg.getAllDevicesMessage());
//            }
//        }
////        else if (msg.msgType == EventBusManager.MsgType.fromWebSocket) {
////            if (msg.isAction()) {
////                websocketstate_ll.setVisibility(View.GONE);
////            } else {
////                websocketstate_ll.setVisibility(View.VISIBLE);
////            }
////        } else if (msg.msgType == EventBusManager.MsgType.fromMqtt) {
////            if (msg.isAction()) {
////                mqttstate_ll.setVisibility(View.GONE);
////            } else {
////                mqttstate_ll.setVisibility(View.VISIBLE);
////            }
////        }
//
//    }

    /**
     * 单个设备的运行状态变化
     *
     * @param message
     */
//    private void setRecordInfo(DeviceMessage message) {
//        if (message != null) {
//            String name = APPConstant.deviceTypeMap.get(message.getDeviceType());
//            String usage = APPConstant.UsageMap.get(message.getUsage());
//            if (1 == message.getUsage()) {
//                for (Devices.Device device : manDevices.getDevices()) {
//                    if (device.getName().equals(name)) {
//                        device.setAction(message.isAction());
//                    }
//                }
//                manFragment.onStateChanged(manDevices);
//            } else if (2 == message.getUsage()) {
//                for (Devices.Device device : womanDevices.getDevices()) {
//                    if (device.getName().equals(name)) {
//                        device.setAction(message.isAction());
//                    }
//                }
//                womanFragment.onStateChanged(womanDevices);
//            } else if (3 == message.getUsage()) {
//                for (Devices.Device device : disabledDevices.getDevices()) {
//                    if (device.getName().equals(name)) {
//                        device.setAction(message.isAction());
//                    }
//                }
//                disabledFragment.onStateChanged(disabledDevices);
//            } else if (4 == message.getUsage()) {
//                commonFragment.setVoiceCtrlTb1(message.isAction());
//            }
//        }
//    }

    /**
     * 更新整体状态
     *
     * @param message
     */
    private void setWholeStateInfo(AllDevicesMessage message) {
//
//        allControlled = message.isControlled();
//        allCotrolled_btn.setChecked(allControlled);
//        //此处的顺序应该与model.Devices中的devices List一一对应
//        manDevices.getDevices().get(0).setAction(message.isAction_M_MainLight());
//        manDevices.getDevices().get(1).setAction(message.isAction_M_SecondaryLight());
//        manDevices.getDevices().get(2).setAction(message.isAction_M_AirPump());
//        manDevices.getDevices().get(3).setAction(message.isAction_M_Audio());
//        manDevices.getDevices().get(4).setAction(message.isAction_M_Sterilamp());
//        manDevices.getDevices().get(5).setValue(message.getValue_M_lightDetector());
//        manDevices.getDevices().get(0).setControlled(message.isControlled_M_MainLight());
//        manDevices.getDevices().get(1).setControlled(message.isControlled_M_SecondaryLight());
//        manDevices.getDevices().get(2).setControlled(message.isControlled_M_AirPump());
//        manDevices.getDevices().get(3).setControlled(message.isControlled_M_Audio());
//        manDevices.getDevices().get(4).setControlled(message.isControlled_M_Sterilamp());
//
//
//        womanDevices.getDevices().get(0).setAction(message.isAction_W_MainLight());
//        womanDevices.getDevices().get(1).setAction(message.isAction_W_SecondaryLight());
//        womanDevices.getDevices().get(2).setAction(message.isAction_W_AirPump());
//        womanDevices.getDevices().get(3).setAction(message.isAction_W_Audio());
//        womanDevices.getDevices().get(4).setAction(message.isAction_W_Sterilamp());
//        womanDevices.getDevices().get(5).setValue(message.getValue_W_lightDetector());
//        womanDevices.getDevices().get(0).setControlled(message.isControlled_W_MainLight());
//        womanDevices.getDevices().get(1).setControlled(message.isControlled_W_SecondaryLight());
//        womanDevices.getDevices().get(2).setControlled(message.isControlled_W_AirPump());
//        womanDevices.getDevices().get(3).setControlled(message.isControlled_W_Audio());
//        womanDevices.getDevices().get(4).setControlled(message.isControlled_W_Sterilamp());
//
//
//        disabledDevices.getDevices().get(0).setAction(message.isAction_D_MainLight());
//        disabledDevices.getDevices().get(1).setAction(message.isAction_D_SecondaryLight());
//        disabledDevices.getDevices().get(2).setAction(message.isAction_D_AirPump());
//        disabledDevices.getDevices().get(3).setAction(message.isAction_D_Audio());
//        disabledDevices.getDevices().get(4).setAction(message.isAction_D_Sterilamp());
//        disabledDevices.getDevices().get(5).setValue(message.getValue_D_lightDetector());
//        disabledDevices.getDevices().get(0).setControlled(message.isControlled_D_MainLight());
//        disabledDevices.getDevices().get(1).setControlled(message.isControlled_D_SecondaryLight());
//        disabledDevices.getDevices().get(2).setControlled(message.isControlled_D_AirPump());
//        disabledDevices.getDevices().get(3).setControlled(message.isControlled_D_Audio());
//        disabledDevices.getDevices().get(4).setControlled(message.isControlled_D_Sterilamp());
//
//
//        manFragment.onStateChanged(manDevices);
//        womanFragment.onStateChanged(womanDevices);
//        disabledFragment.onStateChanged(disabledDevices);
//
//        commonFragment.setVoiceCtrlTb1(message.isAction_C_VoiceGuide());
//        commonFragment.setVoiceCtrlTb2(message.isControlled_C_VoiceGuid());
//        commonFragment.setWaterMeterTvValue(message.getValue_C_WaterMeter() + "");
//        commonFragment.setElecMeterTvValue(message.getValue_C_ElecMeter() + "");
//
//
    }

    @Override
    public boolean isControlled() {
        return allControlled;
    }


}
